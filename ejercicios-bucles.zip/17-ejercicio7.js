/*
Tabla de multiplicar de un número introducido por pantalla
*/
