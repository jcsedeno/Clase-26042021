'use strict'

/*
Mostrar en el navegador todos los números divisores de un número introducido en un prompt.
*/


