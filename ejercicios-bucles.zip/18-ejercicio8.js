'use strict'

/*
Hacer una calculadora que pida dos números por pantalla.
Si metemos uno mal que nos los vuelva a pedir.
En el cuerpo de la página y por la consola el resultado
de sumar, restar, multiplicar y dividir esas dos cifras.
*/
