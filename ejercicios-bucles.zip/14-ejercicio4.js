'use strict'

/*
Mostrar todos los números impares que hay entre dos números introducidos por el usuario
*/





